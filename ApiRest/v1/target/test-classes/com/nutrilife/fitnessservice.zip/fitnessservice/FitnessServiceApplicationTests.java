package com.nutrilife.fitnessservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FitnessServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
